//app/routes.js

var register = require('./models/register');
var login = require('./models/login');
var otp = require('./models/otp');
var url   = require('url');


	module.exports = function(app,io) {
	app.get('/api/checkUserCredentials', function(req, res) {
		var db = req.app.locals.db;
		var userCredentials = url.parse(req.url, true).query;
		login.checkUserCredentials(db, userCredentials, function(data) {
			if(data == "Valid User"){
				res.end("Valid User");
			}else{
				res.end("Invalid User");
			}
		});
	});
	
	app.get('/api/verifyOTP', function(req, res) {
		var db = req.app.locals.db;
		var otpCredentials = url.parse(req.url, true).query;
		otp.verifyOTP(db, otpCredentials, function(data) {
			if(data == "Valid"){
				res.end("Valid");
			}else{
				res.end("Invalid");
			}
		});
	});
	
	
	
	
	app.post('/api/registerUser', function(req, res) {
		var db = req.app.locals.db;
		var userInfo = req.body;
		register.registerUser(db, userInfo, function(data) {
			res.end(data);
		});
	});

   

	// frontend routes
	// route to handle all angular requests
	app.get('*', function(req, res) {
		res.sendfile('./client/index.html'); // load our public/index.html file
	});
};
