var nodemailer     = require('nodemailer');
var fs 			   = require('file-system');


function registerUser(db,userInfo,callback){
	var status = "ERROR";
	var collection = db.collection('User_Details');
	
		collection.save(userInfo,{ upsert: true }, function (err, result) {
			if (err) {
				console.log("Error in registering user in database");
				console.log(err);
				callback("ERROR");
			}else{
				var mailCredentials = fs.readFileSync("properties.json");
				mailCredentials = JSON.parse(mailCredentials);
				var transporter = nodemailer.createTransport({

					host: mailCredentials.mailHost, // hostname
					secureConnection: false, // TLS requires secureConnection to be false
					port: mailCredentials.mailPort, // port for secure SMTP
					auth: {
						user: mailCredentials.userId,
						pass: mailCredentials.password
					},
					tls: {
						ciphers:'SSLv3'
					}
				});


				var text = 'Your OTP is '+userInfo.OTP;
				var mailOptions = {
					from: mailCredentials.userId, // sender address
					to: userInfo.email,//list of receivers
					subject: 'Find your OTP.', // Subject line
					text: text , // plaintext body
					/*attachments: [
						{
							
						}
					]*/
				};
				transporter.sendMail(mailOptions, function(error, info){
					transporter.close(); // shut down the connection pool, no more messages.
					if(error){
						console.log("ERROR  IN SENDING MAIL : "+error);
					}else{
						console.log("Email Sent successfully");
					}
				});



				callback(JSON.stringify(userInfo));
			}
		});
}




exports.registerUser = registerUser;
