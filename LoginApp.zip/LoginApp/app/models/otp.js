

function verifyOTP(db, otpCredentials, callback){
	var collection = db.collection('User_Details');
	collection.findOne({email: otpCredentials.email,OTP: otpCredentials.OTP}, function(err, user){
		if(err) {
			console.log(err);
			callback("Error");
		}
		else if(user){

			collection.update({email: otpCredentials.email},{$set: {"OTP_Verified":true}},function (err, result){
				if (err) {
					console.log("ERROR in updation");
				}else{
					console.log("updated successfully");
				}
			});

			callback("Valid")
		}
		else {
			callback("Invalid");
		}
	});
};

exports.verifyOTP = verifyOTP;