/* checkUserCredentials function to check if userId and password exist in database or not*/
function checkUserCredentials(db, userCredentials, callback){
	var collection = db.collection('User_Details');
	collection.findOne({email: userCredentials.email,password: userCredentials.password,OTP_Verified:true}, function(err, user){
		if(err) {
			console.log(err);
			callback("Error");
		}
		else if(user){
			callback("Valid User")
		}
		else {
			console.log("Invalid")
			callback("Invalid User");
		}
	});
};




exports.checkUserCredentials = checkUserCredentials;