//server.js

//modules =================================================
var express        = require('express');          // create app with express
var bodyParser     = require('body-parser');      // pull information from HTML POST
var methodOverride = require('method-override');
var mongodb        = require('mongodb');
var io			   = require('socket.io');
var fs 			   = require('file-system');
var https 		   = require('https');

var app = express();

app.use(bodyParser.json({limit: '50mb'}));
app.use(bodyParser.urlencoded({limit: '50mb', extended: true}));

//reading node server IP,port and mongodb port from properties.json
var nodeDetails = fs.readFileSync("properties.json");
nodeDetails = JSON.parse(nodeDetails);
global.webAppDir = __dirname;
//Connection URL. This is where your mongodb server is running.
var url = 'mongodb://'+nodeDetails.ServerIp+':'+nodeDetails.mongoDbPort+'/LoginApp';
var mongoClient = mongodb.MongoClient;
//connect method to connect to the Server
mongoClient.connect(url, function (err, db) { //{ server: { poolSize: 1  }},-> add this vreate sinsgle connection to mongodb.Best to stick with the default 

	if (err) {
		console.log('Mongodb is unable to connect to the mongoDB server. Error: ', err);
	} else {
		console.log('Mongodb Server connection established to:', url);
		app.locals.db = db;

		
		db.createCollection("User_Details", function(err, collection){
			if (err){
				console.log('Collection : User_Details');
				console.log(err);
			};
		});
	}

});	

//set node js server port 
var port  = nodeDetails.ServerPort; 

//get all data/stuff of the body (POST) parameters
//parse application/json 
app.use(bodyParser.json()); 

//parse application/vnd.api+json as json
app.use(bodyParser.json({ type: 'application/vnd.api+json' })); 

//parse application/x-www-form-urlencoded
app.use(bodyParser.urlencoded({ extended: true })); 

//override with the X-HTTP-Method-Override header in the request. simulate DELETE/PUT
app.use(methodOverride('X-HTTP-Method-Override')); 

//set the static files location /public/img will be /img for users
app.use(express.static(__dirname + '/client')); 

//startup our app at defined port

var listen = app.listen(port ); 
console.log(' server started at port:', port );

//open a listener for socket.io, so that server will listen for any websocket connections that may occur.
var socket = io.listen(listen);   
socket.on('connection', function(socket){
});
//routes ==================================================
require('./app/routes')(app,socket); // configure our routes
//export app           
exports = module.exports = app;  