angular.module('loginCtrl', ['ngMaterial'])
.controller('loginController', ["$scope","$rootScope","$state","Login", function($scope,$rootScope,$state,Login) { 

	$scope.verifyLogin = function(){ 
		
		
			var userCredentials = {
					email: $scope.loginEmail,
					password: $scope.loginPassword
			};
			Login.checkUserCredentials(userCredentials).then(function(response){
				console.log(response.data);
				if(response.data == "Valid User"){
					alert("Valid User");
				}else{
					alert("Invalid user");
				}		
			});
	}

}]);       