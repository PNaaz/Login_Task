angular.module('loginService', []).factory('Login', ['$http',"$rootScope", function($http,$rootScope) {
	
	return {
		checkUserCredentials : function(userCredentials) {
			return $http.get('/api/checkUserCredentials?',{
				params: userCredentials
			});
		}
	}
}]);