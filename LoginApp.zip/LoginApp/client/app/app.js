var app = angular.module('LoginApp', ['loginCtrl','registerCtrl','loginService',"registerService","otpCtrl","otpService","ui.router","ui.bootstrap","ngMaterial"])

app.config(function($stateProvider, $urlRouterProvider,$httpProvider) {

	
	$urlRouterProvider.otherwise("/register");
	// Now set up the states
	$stateProvider
	
	.state('login', {
		url: "/login",
		templateUrl: "app/login/login.html",
		controller:'loginController'
	})
	.state('register', {
		url: "/register",
		templateUrl: "app/main/register.html",
		controller:'registerController'
	})
	.state('OTP', {
		url: "/OTP",
		templateUrl: "app/otp/otp.html",
		controller:'otpController'
	})

});

app.controller('indexCtrl', function ($rootScope, $scope, $state) {
	
	
	
});
