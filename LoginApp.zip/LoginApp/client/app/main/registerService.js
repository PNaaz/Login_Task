angular.module('registerService', []).factory('Register', ['$http',"$rootScope", function($http,$rootScope) {
	
	return {
		
		saveUser : function(userInfo) {
			return $http.post('/api/registerUser',userInfo);
		}
	}
}]);