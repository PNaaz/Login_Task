angular.module('registerCtrl', ['ngMaterial'])
.controller('registerController', ["$scope","$rootScope","$state","Register", function($scope,$rootScope,$state,Register) { 

$scope.submitRegister = function(){
	var randomNumber = Math.floor(Math.random() * 9999) - 10000;
	if(randomNumber <0){
		randomNumber = -(randomNumber);
	}
	var userData = {
			userName:$scope.userName,
			email:$scope.email,
			password:$scope.password,
			OTP:randomNumber.toString()
		}
		console.log(userData)
		Register.saveUser(userData).then(function(response){
			if(response.data){
				$rootScope.userEmail = response.data.email;
				$state.go("OTP");
			}
		})
}


}]);