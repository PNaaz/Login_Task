angular.module('otpCtrl', ['ngMaterial'])
.controller('otpController', ["$scope","$rootScope","$state","Otp", function($scope,$rootScope,$state,Otp) { 

console.log($rootScope.userEmail);
$scope.verifyOTP = function(){
	var otpCredentials = {
					email: $rootScope.userEmail,
					OTP: $scope.otp
			};
			Otp.verifyOTP(otpCredentials).then(function(response){
				console.log(response.data);
				if(response.data == "Valid"){
					alert("OTP verified Successfully");
					$state.go("login");
				}else{
					alert("Invalid OTP");
				}		
			});
}

}]);