angular.module('otpService', []).factory('Otp', ['$http',"$rootScope", function($http,$rootScope) {
	
	return {
		
		verifyOTP : function(otpCredentials) {
			return $http.get('/api/verifyOTP?',{
				params: otpCredentials
			});
		}
	}
}]);